package com.example.egzamin1;

public class Item {
    String note;

    Item(String note){
        this.note = note;
    }
    public String getNote(){
        return note;
    }
}
