package com.example.egzamin1;

import android.view.View;
import android.widget.EditText;
import android.widget.TextClock;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ViewHolder extends RecyclerView.ViewHolder {
    TextView textList;
    public ViewHolder(@NonNull @org.jetbrains.annotations.NotNull View itemView){
        super(itemView);
        textList = itemView.findViewById(R.id.textList);
    }

}